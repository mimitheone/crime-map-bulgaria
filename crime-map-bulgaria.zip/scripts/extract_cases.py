# TODO: Parse bulletins and extract murder-related cases
