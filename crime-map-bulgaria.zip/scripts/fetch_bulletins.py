# TODO: Add logic to download bulletins from MVR websites
